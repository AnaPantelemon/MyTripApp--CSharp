﻿using Microsoft.EntityFrameworkCore;
using MyTrip.Models;

namespace MyTrip.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Trip> Trips { get; set; }

        
               
        public DbSet<User> Users { get; set; }


    }
}
