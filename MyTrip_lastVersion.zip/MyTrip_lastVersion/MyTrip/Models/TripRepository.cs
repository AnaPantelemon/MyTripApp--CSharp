﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MyTrip.Models
{
    public class TripRepository : ITripRepository
    {
        private AppDbContext _appDbContext;
        public TripRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void AddTrip(Trip trip)
        {
            trip.UserId = 1;
           
            _appDbContext.Trips.Add(trip);
           
            _appDbContext.SaveChanges();
        }
        
        public void DeleteTrip(Trip trip)
        {
           
            _appDbContext.Trips.Remove(trip);
            _appDbContext.SaveChanges();
        }

      

        public IEnumerable<Trip> GetAllTrips(int userId)
        {
            return _appDbContext.Trips.Where(trip => trip.UserId == userId);
        }

        public Trip GetTripById(int tripID)
        {
            return _appDbContext.Trips.FirstOrDefault(t => t.TripId == tripID);
        }
    }
}
