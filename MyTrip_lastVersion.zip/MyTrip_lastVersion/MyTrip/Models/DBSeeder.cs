﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyTrip.Models
{
    public class DBSeeder
    {
        private readonly AppDbContext _context;

        public DBSeeder(AppDbContext context)
        {
            _context = context;
        }

        public void Seed()
        {
           
            _context.Database.EnsureCreated();
            var trips = new List<Trip>() {
                        new Trip(){
                            //TripId=1,
                            TripName="Sulina",
                            StartDate=new DateTime(2008, 6, 1, 7, 47, 0),
                            EndDate=new DateTime(2008, 6, 1, 7, 47, 0),
                            Impressions="Superba vremea si marea...Soare puternic si valuri mari",
                            Location="Delta Dunarii",
                            Title1="First picture af the trip",
                            Title2="Second picture af the trip",
                            Description1="Delta Dunarii",
                            Description2="Sulina",
                            UserId=1
                        }
                    };

            if (!_context.Users.Any())
            {
                //need to create sample data
                var user = new User()
                {
                    //UserId = 1,
                    LastName = "Marin",
                    FirstName = "Calin",
                    UserName = "1234",
                    City = "Brasov",
                    Adress = "Nisipului 34",
                    UserTrips = trips
                };

                _context.Users.Add(user);
                _context.SaveChanges();

            }

        }
    }
}

