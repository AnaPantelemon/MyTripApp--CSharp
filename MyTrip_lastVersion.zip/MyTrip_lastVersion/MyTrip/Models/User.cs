﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyTrip.Models
{
    public class User
    {
            [Required]
            public int UserId { get; set; }
            [Required]  
            [RegularExpression("^[a-zA-z]+$", ErrorMessage = "First name must contain only letters")]
            public string FirstName { get; set; }
            

            [Required]
            [RegularExpression("^[a-zA-z]+$", ErrorMessage = "Last name must contain only letters")]
            public string LastName { get; set; }

            [Required]
            [MinLength(4,ErrorMessage="Lenght must be at least 4 characters")]
            public string UserName { get; set; }

            [StringLength(20, ErrorMessage = "City ")]
            [RegularExpression("^[a-zA-z]+$", ErrorMessage = "City must contain only letters")]
            public string City { get; set; }
            public string Adress { get; set; }

            public List<Trip> UserTrips { get; set; }
    }
    }

