﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyTrip.Models
{
    public class Trip
    {

       
        public int TripId { get; set; }
         

        [Required]
        [StringLength(50, ErrorMessage = "Trip name is required")]
        public string TripName { get; set; }


        [DataType(DataType.Date, ErrorMessage = "Please enter a valid start date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime StartDate { get; set; }


        [DataType(DataType.Date, ErrorMessage = "Please enter a valid end date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public DateTime EndDate { get; set; }

        [StringLength(5000, ErrorMessage = "Use maximum 5000 characters")]
        public string Impressions { get; set; }
        [MaxLength]
        public byte[] Photo1 { get; set; }
        [MaxLength]
        public byte[] Photo2 { get; set; }
        public string Location { get; set; }
        public string Description1 { get; set; }
        public string  Description2 { get; set; }

        public string Title1 { get; set; }
        public string Title2 { get; set; }

        public int UserId { get; set; }

        [NotMapped]
       [BindProperty]
        public IFormFile file1 { get; set; }

        [NotMapped]
        [BindProperty]
        public IFormFile file2 { get; set; }

      

    }

}
