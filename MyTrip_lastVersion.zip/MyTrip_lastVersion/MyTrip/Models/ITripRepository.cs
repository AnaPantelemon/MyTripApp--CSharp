﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyTrip.Models
{
    public interface ITripRepository
    {
        IEnumerable<Trip> GetAllTrips(int id);
        Trip GetTripById(int tripID);
        void AddTrip(Trip trip);
        void DeleteTrip(Trip trip);
      
    }
}
