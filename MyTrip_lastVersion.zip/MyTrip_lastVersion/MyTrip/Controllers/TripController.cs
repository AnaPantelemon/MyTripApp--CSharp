﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyTrip.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace MyTrip.Controllers
{
    public class TripController :Controller
    {
        private ITripRepository tripRepository;
        public TripController(ITripRepository _tripRepository)
        {
            tripRepository = _tripRepository;
        }


        [HttpGet("AddTrip")]
        public IActionResult AddTrip(int id)
        {
            if (id != null) {
                Trip trip = tripRepository.GetTripById(id);
                return View(trip);
              }
            return View();
        }

        [HttpPost("AddTrip")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddTrip(Trip trip,int id) {
            
            if (id > 1)
            {
                Trip oldTrip = tripRepository.GetTripById(id);
                trip.Photo1 = oldTrip.Photo1;
                trip.Photo2 = oldTrip.Photo2;
                tripRepository.DeleteTrip(oldTrip);
            }
          
            if (ModelState.IsValid)

            {
                trip.UserId = 1;
                if (trip.file1 != null)
                {
                    using (var memoryStream1 = new MemoryStream())
                    {
                        await trip.file1.CopyToAsync(memoryStream1);
                        if (memoryStream1.Length < 2097152)
                        {
                            trip.Photo1 = memoryStream1.ToArray();

                        }
                    }
                }
                if (trip.file2 != null)
                {
                    using (var memoryStream2 = new MemoryStream())
                    {
                        await trip.file2.CopyToAsync(memoryStream2);
                        if (memoryStream2.Length < 2097152)
                        {
                            trip.Photo2 = memoryStream2.ToArray();

                        }
                    }
                }
   
                tripRepository.AddTrip(trip);
            }
            else
            {
                ModelState.AddModelError("File", "File is too large");
                return View();
            }
            
            return Redirect("/Home/Index/"+ trip.TripId);

        }
       

        


        [HttpGet("Delete")]
        public IActionResult Delete(int id) {

            Trip trip = tripRepository.GetTripById(id);
            //tripRepository.DeleteTrip(trip);
            //return Redirect("/Home/Index/" + trip.TripId);
            return View(trip);
        }

        [HttpPost("Delete")]
        public IActionResult DeleteFromDB(int id)
        {
            Trip toDelete = tripRepository.GetTripById(id);
            tripRepository.DeleteTrip(toDelete);
            
            Trip currentTrip = tripRepository.GetAllTrips(1).OrderByDescending(trip => trip.TripId).FirstOrDefault();
            return Redirect("/Home/Index/" + currentTrip.TripId);

        }
        
    }
}
