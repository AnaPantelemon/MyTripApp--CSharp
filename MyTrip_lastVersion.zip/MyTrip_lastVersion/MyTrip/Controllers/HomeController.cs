﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyTrip.Models;
using MyTrip.ViewModels;

namespace MyTrip.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IUserRepository _userRepository;
        private readonly ITripRepository _tripRepository;

        public HomeController(ILogger<HomeController> logger, IUserRepository userRepository, ITripRepository tripRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
            _tripRepository = tripRepository;
           
        }
       
        public IActionResult Index(int id)
        {
            var userTripList = new TripList();
            
            var user = _userRepository.GetUserById(1);
            if (user != null)
            {
                var trips = _tripRepository.GetAllTrips(1).ToList();
                userTripList.CurrentUserTrips = trips;
                userTripList.CurrentUserID = user.UserId;
                userTripList.CurrentTripNamesList = trips.Select(trip => trip.TripName).ToList();
                
                userTripList.CurrentTrip = trips.Where(trip => trip.TripId== id).FirstOrDefault()??trips.OrderByDescending(trip=>trip.TripId).FirstOrDefault();
                

                    return View(userTripList);
            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
