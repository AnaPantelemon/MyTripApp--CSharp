﻿using MyTrip.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyTrip.ViewModels
{
    public class TripList
    {
        public int CurrentUserID { get; set; }
        public List<Trip> CurrentUserTrips { get; set; }
        public List<string> CurrentTripNamesList { get; set; }
        public Trip CurrentTrip { get; set; }
       



    }
}
